# Nguồn quy trình và những lựa chọn AIM ghi đè

Bộ này tổng hợp quy trình thực hiện trong chat AIM, chat “kịch bản AI”, khung AIM người dùng đã chốt và hai bộ skill See The Light người dùng đã nạp. Ngày đóng gói: 25/11/2026. Các file bên trong `archive/` được giữ để tra cứu phương pháp gốc, không tự trở thành lệnh hiện hành.

| Mặc định của nguồn cũ | Quyết định áp dụng cho AIM |
|---|---|
| Video “Bài học từ…” dùng thương hiệu đỏ SanSan/See The Light | Khung xanh ngọc AIM / AI MANAGEMENT có sẵn |
| Khung mẫu AIM ban đầu dài 3 giây, chữ 39 px | Giữ hook đến hết lời nói, cắt trước từ đầu body; các tập mới dùng chữ 31 px, có trường hợp 29 px khi cần tránh dòng lẻ |
| Bộ bài học 176–188 tiếng, 35–40 giây | Bài AI theo thời lượng yêu cầu từng bộ, không kéo dài hoặc tăng tốc bài đã có audio |
| Nội dung giới hạn người Việt nổi tiếng với chủ đề phát triển bản thân | Tin AI thế giới, doanh nhân và doanh nghiệp, sự kiện và nghiên cứu cụ thể |
| Ít nhất 80% ảnh là nhân vật | Ảnh liên quan đúng mạch tin AI: nhân vật, công ty, sản phẩm hoặc cảnh minh họa phù hợp; không áp tỷ lệ người cho bài không có một nhân vật chính |
| Mặc định không nhạc | Người dùng đã yêu cầu nhạc và chốt khoảng −20 dB; có nguồn kèm theo |
| Chú thích nguồn từng đổi chỗ theo thử nghiệm | Một dòng ở góc trên bên trái, x=72, y=84 |
| Ảnh giữa ban đầu nhỏ | Thân ảnh phủ hết chiều ngang 720 px, chữ dưới ảnh |
| Phụ đề ASR thô | Kịch bản chuẩn + căn CTC, ASR kiểm chéo, tên chuẩn trên màn hình |

Những nguyên tắc giữ lại: chuyển động pan/zoom tuyến tính, kiểm tra tên riêng, không chia đều mốc từ, phụ đề trắng sang vàng, không lặp ảnh, không bàn giao khi vẫn đang render, kiểm tra bản mã hóa thực.

Khung và logo hiện có được tái sử dụng như tài sản người dùng đã duyệt. Yêu cầu “không tự tạo ảnh” áp dụng việc tìm hình cho video mới; không yêu cầu dựng lại logo hoặc khung.

Nhạc gốc và ảnh stock không được nhúng vào ZIP này. Gói lưu nguồn và hướng dẫn lấy lại tài liệu cần thiết; quyền tái sử dụng từng ảnh/nhạc vẫn theo điều khoản của nguồn. Phông Inter đi cùng giấy phép OFL. Không áp một giấy phép mở chung cho toàn bộ tài sản hoặc tài liệu gốc.
