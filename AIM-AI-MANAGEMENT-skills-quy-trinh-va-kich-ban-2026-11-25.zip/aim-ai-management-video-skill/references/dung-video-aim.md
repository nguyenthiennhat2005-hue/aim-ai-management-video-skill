# Dựng và kiểm tra video AIM

## 1. Chọn đầu vào

Tìm MP3 và HTML/JSON mới nhất trong Downloads. Khớp **bộ + số bài + tiêu đề + nội dung**. Bộ 32 bài AI sửa 09/11 mới hơn MP3 05/11; bản 42 sửa 18/11 mới hơn bản 42 đầu tiên. Không nhầm với bộ Bản Đồ Doanh Chủ có cùng số thứ tự.

Tạo thư mục dự án riêng, giữ nguyên file MP3, lưu bản chữ gốc và mã SHA-256. `scripts/init_project.py` tạo dự án với renderer, aligner, verifier, phông, khung và lời đã duyệt; không tải ảnh, gọi Vbee hay xuất bản nội dung.

```sh
python3 scripts/init_project.py --episode 25 --voice /path/to/25.mp3 --music /path/to/music.wav --out /path/to/project
```

Chọn nhạc trong thư viện người dùng đã cho phép. Hai bản lưu trước đây:

- `AIM-nhac-01-Reel-1-va-2.wav`: từ page KHỞI NGHIỆP, âm thanh gốc ở https://www.facebook.com/reel/1670281907901655 và https://www.facebook.com/reel/2220861011798219.
- `AIM-nhac-02-Reel-3-Vuong-Hong.wav`: từ https://www.facebook.com/reel/1496065549036217.

Chưa biết tên bài/chủ sở hữu âm nhạc thì giữ mô tả nguồn, không đoán tên hoặc coi là miễn bản quyền. Đảm bảo nhạc đủ dài; đổi bài hoặc thiết kế điểm lặp mượt khi thật sự cần.

## 2. Căn từ

Cài các gói render trong `requirements.txt`. Căn lại lời cần thêm torch, transformers, faster-whisper; phiên bản thực đã chạy nằm ở `runtime-versions.json`. Các mô hình tải từ Hugging Face không được nhúng trong gói này.

```sh
python3 align.py --model nguyenvulebinh/wav2vec2-base-vietnamese-250h --whisper small
```

Có thể dùng đường dẫn mô hình đã tải sẵn. Aligner giải mã MP3 sang 16 kHz, dùng wav2vec2 tiếng Việt để căn bản lời chuẩn; Whisper chạy độc lập để kiểm chéo. Xem các từ có `score < -1.5`, khác biệt giữa hai bản nhận dạng, tên riêng và số liệu. Phiên âm tên phải khớp Vbee nhưng chữ trên video vẫn là tên chuẩn. Không thay lời được duyệt theo lỗi nhận dạng. Không dùng timestamp Whisper thô hoặc chia đều thời gian một câu cho các từ.

`words.json` có `id`, `w`, `spoken`, `s`, `e`, `score`, `review_flag`. ID đếm từ 0, gồm cả hook. Độ dài lấy từ audio thực. Các bài 24–25 căn hook đến trước từ đầu body ở khoảng 4,733 giây; đây là kết quả riêng từng bài, không phải mốc cố định cho mọi video.

## 3. Lên cảnh, chọn ảnh và chia phụ đề

Viết `edit-config.json` theo mẫu `example-25/edit-config.json` sau khi biết mốc từ:

| Trường | Ý nghĩa |
|---|---|
| `hook_image` | Tên tệp trong `assets/` |
| `source_labels` | Tên tệp → một tên nguồn ngắn |
| `photo_focal_points` | Tên tệp → tọa độ tâm tương đối x, y |
| `scenes` | Mỗi cảnh: `[word_id, file, crop_or_null, motion, description, dissolve_seconds]`; cảnh đầu dùng `null` thay word_id |
| `caption_ids` | Các khoảng `[i,j]` liên tiếp, gồm i và không gồm j; phủ đủ mọi từ body đúng một lần |
| `protected_hook_phrases` | Chỉ những tên/từ ghép cần giữ liền khi lấp dòng |
| `full_frame_assets` | Ảnh sản phẩm hoặc đồ thị cần giữ nguyên toàn bộ khung |
| `hook_font_size` | Mặc định 31; đo thực tế và xem preview |
| `hook_pan_start_fraction` | Vị trí bắt đầu pan tương đối; điều chỉnh để không cắt mặt/logo |

Ảnh lấy từ web, không tạo ảnh mới. Ưu tiên tư liệu chính thức cho người, logo, sản phẩm và giao diện. Ảnh stock chỉ minh họa, không gán họ là nhân viên công ty hoặc người trong sự kiện. Giữ đủ nội dung đồ thị và giao diện; không cắt mất số hoặc nhãn để ép vừa hình.

Ghi `sources.json` với tên tệp, vai trò, tác giả/đơn vị, trang gốc, URL tải, giấy phép, kích thước và SHA-256. So trùng bằng hash và bằng mắt; ảnh cùng buổi chụp gần giống cũng cần loại. Tránh watermark, ảnh nhầm người, ảnh quá nhỏ. Ưu tiên ảnh khác các tập cũ.

Phụ đề thường 4–6 tiếng một cụm, một dòng, nối đủ lời. Giữ từ ghép, tên riêng, số + đơn vị; không ngắt máy móc theo số từ. Đo bề rộng thực ≤520 px với Inter Bold 31, dự phòng 29/27/26 khi cần; nếu vẫn tràn, chia lại cụm. Không bỏ chữ để vừa.

## 4. Thông số hình đã chốt

| Thành phần | Thiết lập ở 720 × 1280 |
|---|---|
| Video | 30 fps, H.264, AAC stereo 48 kHz, yuv420p, BT.709 |
| Khung hook | `assets/khung-hook.png`, màu xanh ngọc và logo AIM có sẵn |
| Hook ảnh | Phủ vùng 720 × 800 phía trên, pan trái tuyến tính 129,33 px |
| Hook chữ | Trắng IN HOA, Arial Bold trên macOS / Inter Bold dự phòng, 31 px, x=48, y=835, bước dòng 51, rộng 620 px |
| Điểm cắt hook | Sau từ cuối hook và trước từ đầu body, căn theo audio; không ép 3 giây |
| Ảnh thân | x=0, y=268, rộng 720, cao 518; ảnh thường cover, nền cùng ảnh phóng lớn làm mờ và tối |
| Chuyển động thân | Pan trái/phải hoặc zoom 10% tuyến tính; fade ngắn nếu phù hợp nhịp, mẫu cuối 0,26 giây |
| Sub | Một dòng dưới ảnh, baseline y=836; trắng `#FFFFFF` → vàng `#FFD400`, viền tối |
| Nguồn | Inter Bold 18 px, x=72, y=84, một dòng ngắn, ví dụ `Nguồn: Netflix` |

Hook lấp đầy dòng theo chiều rộng; từ kế tiếp không vừa mới xuống dòng. Ngoại lệ giữ tên và từ ghép. Không ép số dòng hoặc tạo dòng cuối chỉ vài chữ khi có cách xếp gần đầy đẹp hơn. Xem toàn bộ hook để bảo đảm không thiếu từ.

Đổi ảnh theo nhịp câu hoặc từ khóa, không chia đều số giây. Cảnh sau có thể có lead hình khoảng 25 ms; phụ đề vẫn căn mốc từ. Không để chữ chạm ảnh hoặc che khuôn mặt.

## 5. Âm thanh và render

MP3 chạy 1×, cân giọng bằng loudnorm hai lượt, mục tiêu −16 LUFS, giới hạn đỉnh thiết kế −1,5 dBTP. Nhạc cân theo **đỉnh thật −20 dBTP**, không nhầm với giảm gain tuyệt đối 20 dB của mọi file. Fade nhạc vào 0,25 giây, ra 0,65 giây. `mix-settings.json` lưu phép đo và gain thực; không cần nhạc/SFX ngoài yêu cầu đã chốt.

```sh
python3 render.py --qa preview
python3 render.py --out AIM-25.mp4
python3 verify.py AIM-25.mp4
```

Xem các frame preview trước render; sửa crop/tâm ảnh, dòng hook và cụm sub khi có lỗi thật. Không mặc định một ảnh đẹp ở khung gốc sẽ không bị cắt đầu khi zoom.

## 6. Kiểm tra bản mã hóa và bàn giao

Verifier kiểm giải mã toàn bộ, 720 × 1280/30 fps, số frame, điểm cắt hook, đủ từ body, quét màu karaoke trên MP4 lệch ≤2 frame so với lịch CTC, âm lượng, tương quan bản trộn và tốc độ giọng. Nó tính riêng phần làm tròn theo frame và đuôi AAC, tránh báo sai vì packet cuối.

Độ lệch quét màu so với lịch dựng **không phải** phép đo ngữ âm độc lập. Cần đối chiếu ASR/CTC và xem thực tế. Xem frame của MP4 ở đầu/cuối hook, các điểm cắt, tên riêng, số liệu, nguồn và câu cuối. Nghe trực tiếp nếu được hỗ trợ; ghi `listening_review: not_performed` khi chưa nghe.

Lưu MP4 + `AIM-NN-nguon-anh-va-nhac.md` vào `Downloads/Video AIM`. Dự án gồm code, config, lời gốc, audio, ảnh, nguồn, mốc từ, caption, timeline, báo cáo QA và checksum; nén ZIP để sửa tiếp. Bản công khai của **gói skill này** chỉ có hướng dẫn, code, khung, dữ liệu kịch bản và ví dụ metadata; không có MP3/nhạc/ảnh stock của video.
