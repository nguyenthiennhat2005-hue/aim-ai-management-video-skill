# Viết kịch bản AI cho AIM

## Chọn đề tài và kiểm chứng

Page tập trung AI trên thế giới: việc làm, doanh nghiệp, phát ngôn của người có tên tuổi, sản phẩm, nghiên cứu và các sự kiện AI cụ thể. Tìm tin mới trên báo uy tín như VnExpress, Fortune, Reuters, TechCrunch; đối chiếu thông báo, nghiên cứu hoặc tài liệu chính thức khi có. Phân biệt ngày đăng với ngày sự kiện.

Lưu URL, đơn vị, ngày và phát biểu gốc. Hook là lời dẫn Việt hóa, không tự đặt trong ngoặc kép như phát ngôn nguyên văn. Giữ chính xác các từ giới hạn như “dự đoán”, “thử nghiệm”, “có thể”, phạm vi quốc gia, thiết bị và thời điểm. Một cáo buộc trong đơn kiện phải được trình bày đúng bối cảnh, không tự biến thành kết luận đã được chứng minh.

## Hook và nhịp kể đã được yêu cầu

- Hook khoảng 4–6 giây, vào thẳng nhân vật/sự kiện và chi tiết bất ngờ. Viết như lời kể để đọc lên tự nhiên.
- Giật tít vừa phải bằng chi tiết, đối lập, nhịp và hệ quả; không bịa số liệu, câu nói hay mức độ triển khai. Các cảnh giả định phải nghe ra là giả định.
- Không dùng dấu gạch dưới hoặc gạch ngang làm dấu phân tách trong lời nói. Giữ chính tả thương hiệu. Người dùng đã yêu cầu bỏ dấu chấm than khỏi bộ hook.
- Hook đã duyệt phải giữ nguyên nếu chỉ được yêu cầu sửa body.

Người dùng nhận thấy người xem rời đi sau khoảng 9 giây. Bản sửa 09/11 vì vậy kéo phần tò mò và câu chuyện đến **giây 15–18**, rồi chuyển sang giải thích nhẹ hơn. Đây là cách sắp xếp thông tin; không phải cho phép sai dữ kiện.

Thân bài nối liền hook: câu sau phát triển từ câu trước, có bối cảnh đủ hiểu, hành động và hệ quả cụ thể. Tránh liệt kê các ô rời, tiểu sử dài, câu dạy đời kiểu poster và CTA lặp lại. Có thể dùng một tình huống đời thường để giải thích nếu nó phù hợp với tin, không ép mọi bài vào một tình huống.

Trong các bài mới 41–44, người dùng muốn phần đầu dồn nhịp và không cần lời dẫn “Theo…” trong giọng đọc. Nguồn vẫn được lưu riêng. Lời giải thích ở cuối nêu giới hạn hoặc bối cảnh cần thiết, thay vì làm mất ý chính của hook.

## Thời lượng và phiên bản

Yêu cầu có thay đổi theo từng bộ, không áp một độ dài cho tất cả:

| Nhóm | Mốc dùng để tham khảo |
|---|---|
| Bộ 40 AI ban đầu | Đã duyệt, sau đó làm bản Vbee khoảng 30 giây |
| Body sửa 09/11 | 32 bài sửa, giữ các hook và 8 bài đã viết caption; audio thực khoảng 27,4–33,7 giây |
| Bài 41–42 ban đầu | Khoảng 20–28 giây |
| Bản 42 sửa 18/11 | Đưa phần cuối cũ lên đầu body, bổ sung khoảng 5 giây, khoảng 30–33 giây |
| Bản nháp 43–44 | Khoảng 25–28 giây, tập trung 15 giây đầu; chưa có MP3 kèm trong gói |

Ước tính trên bản **đã phiên âm Vbee**, không đếm thẻ nghỉ như tiếng đọc. Mốc đo của bộ cũ: khoảng 4,91 tiếng/giây ở Ngọc Huyền 1.1×, cộng các nhịp nghỉ. Độ dài MP3 thực là căn cứ cuối khi dựng. Không tăng tốc MP3 để ép vào dự đoán.

## Dữ liệu và đầu ra

`data/kich-ban-ai-moi-nhat.json` lưu 40 bài từ HTML sửa 09/11, thêm 41 và **42 bản sửa**. Các trường chính: `n`, `title`, `hook`, `body`, `sources`, `revision`, `status`; phần lớn bài có `tts`. Bản TTS 42 mới ở `data/vbee-42-ban-sua.txt`. Đừng nhầm bản 42 cũ trong lịch sử chat với bản cuối.

Khi có bài mới, lưu riêng bản sạch để duyệt, bản đọc Vbee và nguồn. Có thể xuất HTML với tìm kiếm, mục lục và nút sao chép từng phần như bộ đã dùng. Khi người dùng yêu cầu nhiều hook trước, đưa danh sách hook để duyệt trước khi viết body hoặc dùng điểm tạo audio. Nếu họ đã yêu cầu cả bài hoặc đã duyệt, tiếp tục theo phạm vi đó.

Caption Facebook: một đoạn ngắn, gợi tò mò, không kể sai hoặc bỏ mất giới hạn quan trọng; thêm hashtag theo yêu cầu. Các caption cũ ở `data/caption-facebook.json` có thể có nhiều phiên bản của cùng bài, chọn bản mới phù hợp với kịch bản hiện tại.
