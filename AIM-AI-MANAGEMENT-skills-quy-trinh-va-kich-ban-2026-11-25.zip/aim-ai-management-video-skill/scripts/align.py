"""Align the locked transcript to the untouched Vbee recording."""
import argparse, json, re, subprocess, unicodedata
from pathlib import Path
import numpy as np
import imageio_ffmpeg
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor

ROOT = Path(__file__).resolve().parent
MODEL = 'nguyenvulebinh/wav2vec2-base-vietnamese-250h'
PRON = {
    'Netflix': ['nét','phlích'], 'Discover': ['đi','xca','vờ'], 'tivi': ['ti','vi'],
    'Klarna': ['xê','lờ','a','na'],
    'Apple': ['áp','pồ'],
    'Amazon': ['a','ma','dôn'], 'Andy': ['an','đi'], 'Jassy': ['gia','xi'],
    'Shopify': ['só','pi','phai'],
    'Palo': ['pa','lô'], 'Alto': ['an','tô'], 'Nikesh': ['ni','két'], 'Arora': ['a','rô','ra'],
    'Fiverr': ['phai','vờ'], 'CEO': ['xi','i','ô'], 'Micha': ['mi','kha'], 'Kaufman': ['kao','phờ','mân'],
    'RAM': ['ram'], 'video': ['vi','đê','ô'],
    'Wallet': ['oa','lịt'], 'Visa': ['vi','sa'], 'Mastercard': ['mát','tờ','cạt'], 'Pro': ['prô'],
    'Hugging': ['hắc','ghing'], 'Face': ['phây','sờ'], 'California': ['ca','li','pho','ni','a'], 'Internet': ['in','tơ','nét'],
    'Zoom': ['dung'], 'Eric': ['e','rích'], 'Yuan': ['ôn'], 'kỳ': ['ki'],
    'VnExpress': ['vi','en','ích','prết'],
    'ChatGPT': ['chát','gi','pi','ti'], 'Adam': ['a','đầm'], 'Fry': ['phrai'],
    'email': ['i','mêu'], 'Excel': ['ếch','xen'],
    'Mark': ['mác'], 'Cuban': ['kiu','bần'],
    'OpenAI': ['ô','pân','ây','ai'], 'Sam': ['sam'], 'Altman': ['ót','mân'],
    'Geoffrey': ['giép','ri'], 'Hinton': ['hin','tần'], 'The': ['đờ'], 'Guardian': ['ga','đi','ân'],
    'Claude': ['clốt'], 'Dario': ['đa','ri','ô'], 'Amodei': ['a','mô','đây'], 'Axios': ['ác','xi','ốt'],
    'Warren': ['oa','ren'], 'Buffett': ['bắp','phét'],
    '2024': ['hai','nghìn','không','trăm','hai','mươi','tư'],
    'Nobel': ['nô','ben'], 'protein': ['prô','tê','in'], 'Demis': ['đe','mít'], 'Hassabis': ['ha','xa','bít'], 'John': ['giôn'], 'Jumper': ['giam','pờ'], 'AlphaFold': ['an','pha','phôn'], 'David': ['đây','vít'], 'Baker': ['bây','cơ'],
    'Nature': ['nây','chờ'], 'AlphaGeometry': ['an','pha','gi','ô','mê','tri'], 'Olympic': ['ô','lim','pích'],
    'Dimensional': ['đi','men','sờ','nồ'], 'San': ['san'], 'Francisco': ['phran','xít','cô'],
    'Elon': ['i','lon'], 'Musk': ['mắt'], 'Saudi': ['xao','đi'], 'Arabia': ['a','râ','bi','a'],
    'Bill': ['bin'], 'Gates': ['ghết'], 'Jimmy': ['gi','mi'], 'Fallon': ['pha','lân'],
    'Jensen': ['giên','xần'], 'Huang': ['hoang'], 'AI': ['ây','ai'],
    'Nvidia': ['en','vi','đi','a'], 'Dubai': ['đu','bai'], 'code': ['cốt'],
    'Robot': ['rô','bốt'], 'robot': ['rô','bốt'], 'Munich': ['miu','ních'],
    'Neura': ['niu','ra'], 'Robotics': ['rô','bót','tích'],
}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default=MODEL)
    ap.add_argument('--whisper', help='Optional path to the faster-whisper model')
    args = ap.parse_args()
    torch.set_num_threads(5)
    proc = Wav2Vec2Processor.from_pretrained(args.model)
    model = Wav2Vec2ForCTC.from_pretrained(args.model).eval()
    audio = ROOT/'assets/loi-doc-vbee.mp3'
    raw = subprocess.check_output([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-i',str(audio),'-ar','16000','-ac','1','-f','f32le','-'])
    wav = np.frombuffer(raw, dtype=np.float32).copy()
    duration = len(wav)/16000
    iv = proc(wav, sampling_rate=16000, return_tensors='pt').input_values
    with torch.inference_mode():
        logits = model(iv).logits[0]
        E = torch.log_softmax(logits, -1).numpy()
    heard = proc.batch_decode(logits.argmax(-1).unsqueeze(0))[0]
    print('CTC:', heard, flush=True)
    vocab=proc.tokenizer.get_vocab()
    blank=proc.tokenizer.pad_token_id
    words=(ROOT/'loi-doc.txt').read_text().split()
    normalize=lambda w:re.sub(r'[^\w]','',unicodedata.normalize('NFC',w))
    spoken=[]; tokens=[]; owner=[]
    for wi,w in enumerate(words):
        word=normalize(w)
        parts=PRON.get(word,[word.lower()])
        spoken.append(parts)
        for part in parts:
            if tokens: tokens.append(vocab['|']); owner.append(-1)
            for c in part:
                if c in vocab: tokens.append(vocab[c]); owner.append(wi)
    S=2*len(tokens)+1
    ext=np.full(S,blank,np.int64); ext[1::2]=tokens
    neg=-1e9; dp=np.full(S,neg); dp[0]=E[0,ext[0]]; dp[1]=E[0,ext[1]]
    bp=np.zeros((len(E),S),np.int8)
    skip=np.zeros(S,bool); skip[3::2]=ext[3::2]!=ext[1:-2:2]
    for t in range(1,len(E)):
        cand=np.stack([dp,np.r_[neg,dp[:-1]],np.where(skip,np.r_[neg,neg,dp[:-2]],neg)])
        arg=cand.argmax(0); dp=cand[arg,np.arange(S)]+E[t,ext]; bp[t]=arg
    s=S-1 if dp[-1]>dp[-2] else S-2
    path=np.zeros(len(E),np.int64)
    for t in range(len(E)-1,-1,-1): path[t]=s; s-=int(bp[t,s])
    starts={}; ends={}; scores={}; best=E.max(1)
    for t,st in enumerate(path):
        if st%2 and (wi:=owner[st//2])>=0:
            starts.setdefault(wi,t); ends[wi]=t
            scores.setdefault(wi,[]).append(float(E[t,ext[st]]-best[t]))
    result=[]
    step=duration/len(E)
    for wi,w in enumerate(words):
        score=round(float(np.mean(scores[wi])),3)
        result.append(dict(id=wi,w=w,spoken=spoken[wi],s=round(starts[wi]*step,3),e=round((ends[wi]+1)*step,3),score=score,review_flag=score<-1.5))
    output=dict(audio='assets/loi-doc-vbee.mp3',duration=duration,model=MODEL,resolution_seconds=step,words=result,ctc_greedy=heard)
    (ROOT/'words.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    if args.whisper:
        from faster_whisper import WhisperModel
        rec=WhisperModel(args.whisper,device='cpu',compute_type='int8',cpu_threads=5)
        segs,_=rec.transcribe(wav,language='vi',beam_size=5,word_timestamps=True,vad_filter=False)
        output['whisper']=[dict(s=x.start,e=x.end,text=x.text.strip(),words=[dict(s=w.start,e=w.end,w=w.word.strip()) for w in x.words]) for x in segs]
        (ROOT/'words.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
        print('Whisper:', ' '.join(x['text'] for x in output['whisper']),flush=True)
    print('Flagged:',[(w['w'],w['s'],w['e']) for w in result if w['review_flag']],flush=True)

if __name__=='__main__': main()
