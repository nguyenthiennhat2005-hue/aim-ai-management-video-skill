"""Create an editable AIM project from approved copy and supplied local audio."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--episode', type=int, required=True)
    ap.add_argument('--catalog', type=Path, default=PACKAGE/'data/kich-ban-ai-moi-nhat.json')
    ap.add_argument('--voice', type=Path, required=True)
    ap.add_argument('--music', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--config', type=Path)
    args = ap.parse_args()
    rows = json.loads(args.catalog.read_text(encoding='utf-8'))
    matches = [x for x in rows if x['n'] == args.episode]
    if len(matches) != 1:
        ap.error('Episode must resolve to one catalog entry.')
    entry = matches[0]
    if entry.get('status') != 'approved':
        ap.error('Choose an approved script or approve a current revision first.')
    for path in [args.voice, args.music]:
        if not path.is_file():
            ap.error(f'Missing supplied audio: {path.name}')
    if args.out.exists() and any(args.out.iterdir()):
        ap.error('Output directory must be new or empty; existing files were preserved.')
    config = None
    if args.config:
        config = json.loads(args.config.read_text(encoding='utf-8'))
        for key in ['hook_image', 'source_labels', 'photo_focal_points', 'scenes', 'caption_ids']:
            if key not in config:
                ap.error(f'Config is missing {key}.')
    root = args.out
    assets = root/'assets'
    assets.mkdir(parents=True, exist_ok=True)
    for name in ['render.py', 'align.py', 'verify.py', 'requirements.txt', 'runtime-versions.json']:
        shutil.copy2(PACKAGE/'scripts'/name, root/name)
    for name in ['khung-hook.png', 'Inter-Bold.ttf', 'Inter-OFL-LICENSE.txt']:
        shutil.copy2(PACKAGE/'assets'/name, assets/name)
    shutil.copy2(args.voice, assets/'loi-doc-vbee.mp3')
    shutil.copy2(args.music, assets/'nhac-nen.wav')
    transcript = entry['hook'].strip()+'\n'+entry['body'].strip()+'\n'
    for name in ['loi-doc.txt', 'loi-doc-nguon.txt']:
        (root/name).write_text(transcript, encoding='utf-8')
    (root/'script-source.json').write_text(json.dumps(entry, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    inputs = dict(script_number=args.episode, revision=entry.get('revision'),
                  catalog_sha256=digest(args.catalog), voice_name=args.voice.name,
                  voice_sha256=digest(args.voice), music_name=args.music.name,
                  music_sha256=digest(args.music), editor_playback_speed=1)
    (root/'source-inputs.json').write_text(json.dumps(inputs, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    if config:
        (root/'edit-config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(f'Created episode {args.episode:02}: {root}')
    print('Next: align the voice, choose sourced images, author/review edit-config.json, preview, render, verify.')


if __name__ == '__main__':
    main()
