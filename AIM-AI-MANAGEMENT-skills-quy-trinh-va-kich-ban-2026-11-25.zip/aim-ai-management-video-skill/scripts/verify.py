"""Check the delivered encode against the Vbee audio and the caption render clock."""
import json, re, subprocess, sys
from pathlib import Path
import numpy as np
from render import Edit, ROOT, A, FPS, W, CAPTION_Y, ffmpeg

def run(args):
    return subprocess.run([ffmpeg(),'-nostdin',*args],capture_output=True,check=True)

def pcm(p):
    return np.frombuffer(run(['-v','error','-i',str(p),'-vn','-ac','1','-ar','16000','-f','f32le','-']).stdout,np.float32)

def main():
    path=Path(sys.argv[1]).resolve(); edit=Edit()
    scan=run(['-hide_banner','-nostats','-i',str(path),'-af','loudnorm=print_format=json','-f','null','-']).stderr.decode()
    assert re.search(r'Video: h264.*720x1280.*30 fps',scan) and re.search(r'Audio: aac.*48000 Hz',scan),scan[:2000]
    levels=json.JSONDecoder().raw_decode(scan[scan.rfind('{'):])[0]
    lufs,peak=float(levels['input_i']),float(levels['input_tp'])
    assert abs(lufs+16)<.8 and peak<=-1.3,(lufs,peak)
    source=pcm(A/'loi-doc-vbee.mp3'); final=pcm(path)
    # Picture rounds the narration up by less than one frame. AAC can then
    # decode with up to one 1024-sample packet of trailing encoder padding.
    # Check both allowances explicitly instead of comparing with a fixed 50 ms.
    voice_padding=edit.duration-len(source)/16000
    codec_padding=len(final)/16000-edit.duration
    assert -1/16000<=voice_padding<1/FPS+1/16000,voice_padding
    assert -1/16000<=codec_padding<=1024/48000+1/16000,codec_padding
    corr=float(np.corrcoef(source,final[:len(source)])[0,1])
    assert corr>.95,corr
    mix_settings=json.loads((ROOT/'mix-settings.json').read_text())
    graph=mix_settings['audio_filter_graph'].replace('[1:a]','[0:a]').replace('[2:a]','[1:a]')
    expected=np.frombuffer(run([
        '-v','error','-i',str(A/'loi-doc-vbee.mp3'),'-i',str(A/'nhac-nen.wav'),
        '-filter_complex',graph,'-map','[a]','-ar','16000','-ac','1','-f','f32le','-',
    ]).stdout,np.float32)
    assert abs(len(expected)/16000-edit.duration)<=1/16000
    assert -1/16000<=(len(final)-len(expected))/16000<=1024/48000+1/16000
    sample_count=min(len(expected),len(final))
    mix_correlation=float(np.corrcoef(expected[:sample_count],final[:sample_count])[0,1])
    assert mix_correlation>.995,mix_correlation
    music_graph=graph[graph.index('[1:a]')+len('[1:a]'):graph.index('[music];')]
    measured_music=run([
        '-hide_banner','-i',str(A/'nhac-nen.wav'),'-af',
        music_graph+',loudnorm=print_format=json','-f','null','-',
    ]).stderr.decode()
    music_levels=json.JSONDecoder().raw_decode(measured_music[measured_music.rfind('{'):])[0]
    music_peak=float(music_levels['input_tp'])
    assert abs(music_peak-mix_settings['target_music_true_peak_dbtp'])<.1,music_levels

    y0=CAPTION_Y-52;h=78
    arg=['-v','error','-i',str(path),'-an','-vf',f'crop={W}:{h}:0:{y0}','-pix_fmt','rgb24','-f','rawvideo','-']
    raw=run(arg).stdout
    decoded=np.frombuffer(raw,np.uint8).reshape((-1,h,W,3))
    assert len(decoded)==edit.frames
    hook_cut=edit.hook_end_frame/FPS
    assert edit.hook_last_word_end<=hook_cut<=edit.body_first_word_start
    assert edit.shot_starts[0]==edit.cues[0]['start_frame']==edit.hook_end_frame
    coverage=[]; observed_diffs=[]; undetected=[]
    for ci,c in enumerate(edit.cues):
        _,yellow,spans,_=edit.tiles[ci]
        alpha=np.asarray(yellow.getchannel('A'))
        for wi,(left,right) in zip(c['word_ids'],spans):
            w=edit.words[wi]; mid=round((w['s']+w['e'])*FPS/2)
            if mid<c['start_frame']: continue
            yy,xx=np.where((alpha>220)&(np.arange(W)[None,:]>=left)&(np.arange(W)[None,:]<right))
            yy=yy+CAPTION_Y-51-y0
            assert len(xx)>12 and yy.min()>=0 and yy.max()<h
            lit=(decoded[mid,yy,xx,0]>145)&(decoded[mid,yy,xx,1]>130)
            coverage.append(float(np.mean(lit)))
            frames=np.arange(max(c['start_frame'],round(FPS*w['s'])-2),min(c['end_frame'],round(FPS*w['e'])+3))
            fg=decoded[frames[:,None],yy,xx,:].astype(np.int16)
            yellowish=(fg[...,0]>125)&(fg[...,1]>110)&(fg[...,0]-fg[...,2]>65)&(fg[...,1]-fg[...,2]>45)
            marked=np.flatnonzero(yellowish.mean(axis=1)>=.28)
            predicted=left+(right-left)*np.clip((frames/FPS-w['s'])/max(.02,w['e']-w['s']),0,1)
            schedule=np.flatnonzero((xx[None,:]<predicted[:,None]).mean(axis=1)>=.28)
            if len(marked) and len(schedule): observed_diffs.append(int(frames[marked[0]]-frames[schedule[0]]))
            else: undetected.append(w['w'])
    assert min(coverage)>.65, min(coverage)
    assert not undetected,undetected
    assert max(map(abs,observed_diffs))<=2,observed_diffs
    report=dict(decode='passed',dimensions=[720,1280],fps=30,frames=len(decoded),hook_frames=edit.hook_end_frame,
                hook_end_seconds=hook_cut,hook_last_word_end_seconds=edit.hook_last_word_end,
                body_first_word_start_seconds=edit.body_first_word_start,
                duration_seconds=len(decoded)/30,voice_source_seconds=len(source)/16000,
                decoded_audio_seconds=len(final)/16000,
                planned_voice_padding_seconds=voice_padding,aac_tail_padding_seconds=codec_padding,
                voice_pcm_correlation=corr,
                expected_mix_pcm_correlation=mix_correlation,music_true_peak_dbtp=music_peak,
                music_integrated_lufs=float(music_levels['input_i']),
                loudness_lufs=lufs,true_peak_dbtp=peak,caption_words_checked=len(coverage),karaoke_words_measured=len(observed_diffs),
                max_offset_frames_from_planned_swipe=max(map(abs,observed_diffs)),
                offset_scope='Encoded color sweep vs CTC-derived render schedule; not independently measured phonetic error.')
    (ROOT/'kiem-tra.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
