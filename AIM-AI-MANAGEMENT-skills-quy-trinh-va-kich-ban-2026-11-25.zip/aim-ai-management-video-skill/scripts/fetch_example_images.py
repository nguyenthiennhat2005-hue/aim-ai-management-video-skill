"""Download the published episode-25 example images from its attribution manifest."""
import argparse
import hashlib
import io
import json
import urllib.request
from pathlib import Path

from PIL import Image, ImageOps


def save_image(raw, output, gif_frame=None):
    im = Image.open(io.BytesIO(raw))
    if gif_frame is not None:
        im.seek(gif_frame)
        im.convert('RGB').save(output, quality=98)
    else:
        ImageOps.exif_transpose(im).convert('RGB').save(output, quality=96)


def main():
    package = Path(__file__).resolve().parents[1]
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest', type=Path, default=package/'example-25/sources.json')
    ap.add_argument('--project', type=Path, required=True)
    args = ap.parse_args()
    root = args.project.resolve()
    if not (root/'loi-doc.txt').is_file():
        ap.error('Initialize the project first.')
    manifest = json.loads(args.manifest.read_text(encoding='utf-8'))
    records = []
    for row in manifest['images']:
        dest = (root/row['asset']).resolve()
        if not dest.is_relative_to(root/'assets'):
            ap.error('Image path must remain inside project/assets.')
        if dest.exists():
            ap.error(f'Existing image preserved: {dest.name}; use an empty project assets set for downloads.')
        url = row['download_url']
        if not url.startswith('https://'):
            ap.error('Expected a public HTTPS image source.')
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=60) as response:
            raw = response.read()
        dest.parent.mkdir(parents=True, exist_ok=True)
        save_image(raw, dest, row.get('source_gif_frame'))
        actual = hashlib.sha256(dest.read_bytes()).hexdigest()
        matched = actual == row['sha256']
        records.append(dict(asset=row['asset'], sha256=actual, matches_snapshot=matched))
        print(dest.name, 'snapshot match' if matched else 'changed bytes: inspect before using')
    (root/'sources.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (root/'downloaded-assets.json').write_text(json.dumps(records, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
