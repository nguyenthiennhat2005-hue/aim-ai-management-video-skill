#!/usr/bin/env python3
"""Render an AIM video using the project edit-config.json and unchanged Vbee voice."""
import argparse, bisect, json, math, shutil, subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps

ROOT=Path(__file__).resolve().parent
A=ROOT/'assets'
CONFIG=json.loads((ROOT/'edit-config.json').read_text())
W,H,FPS=720,1280,30
HOOK_PAN_PX=194*W/1080
HOOK_PAN_START_FRACTION=CONFIG.get('hook_pan_start_fraction',.5)
CAPTION_LEAD_SECONDS=.025
HOOK_TEXT_WIDTH=620
HOOK_FONT_SIZE=CONFIG.get('hook_font_size',31)
CAPTION_Y=836
CREDIT_XY=(72,84)
CREDIT_FONT_SIZE=18
CAPTION_TEXT_WIDTH=520
PHOTO_TOP,PHOTO_HEIGHT=268,518
FULL_FRAME_ASSETS=set(CONFIG.get('full_frame_assets',[]))
SOURCE_LABELS = CONFIG['source_labels']
PHOTO_FOCAL_POINTS = CONFIG['photo_focal_points']
SCENES = CONFIG['scenes']
CAPTION_IDS = CONFIG['caption_ids']

def ffmpeg():
    if exe:=shutil.which('ffmpeg'): return exe
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

def font(size,title=False):
    local=Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')
    return ImageFont.truetype(str(local if title and local.exists() else A/'Inter-Bold.ttf'),size)

def cover(im,w,h,anchor=(.5,.5)):
    return ImageOps.fit(im,(w,h),Image.Resampling.LANCZOS,centering=anchor)

def stamp(t):
    ms=round(t*1000); hours,ms=divmod(ms,3600000); minutes,ms=divmod(ms,60000); seconds,ms=divmod(ms,1000)
    return f'{hours:02}:{minutes:02}:{seconds:02},{ms:03}'

def source_credit(canvas,asset):
    xy=CREDIT_XY
    text='Nguồn: '+SOURCE_LABELS[asset]
    f=font(CREDIT_FONT_SIZE)
    assert f.getlength(text)<=W-xy[0]-48,(asset,f.getlength(text))
    ImageDraw.Draw(canvas).text(xy,text,font=f,anchor='lt',fill=(225,236,232),
                                stroke_width=2,stroke_fill=(8,23,20))

class Edit:
    def __init__(self):
        d=json.loads((ROOT/'words.json').read_text())
        self.words=d['words']; self.audio_duration=d['duration']
        self.frames=math.ceil(FPS*self.audio_duration); self.duration=self.frames/FPS
        transcript=(ROOT/'loi-doc.txt').read_text()
        assert [w['w'] for w in self.words]==transcript.split()
        opening_words=transcript.splitlines()[0].split()
        self.hook_words=len(opening_words)
        self.hook_last_word_end=self.words[self.hook_words-1]['e']
        self.body_first_word_start=self.words[self.hook_words]['s']
        self.hook_end_frame=max(math.ceil(self.hook_last_word_end*FPS),
                                math.floor(self.body_first_word_start*FPS))
        assert [k for i,j in CAPTION_IDS for k in range(i,j)]==list(range(self.hook_words,len(self.words)))
        self.hook=Image.open(A/'khung-hook.png').convert('RGBA')
        assert self.hook.size==(W,H)
        self.raw=Image.open(A/CONFIG['hook_image']).convert('RGB')
        self.credit_shade=Image.new('RGBA',(W,112),(5,19,16))
        alpha=Image.fromarray(np.linspace(154,0,112,dtype=np.uint8).reshape((112,1)))
        self.credit_shade.putalpha(alpha.resize((W,112)))
        self.tfont=font(HOOK_FONT_SIZE,title=True)
        self.headlines=[]
        line=''
        opening_text = ' '.join(opening_words).upper()
        for phrase in CONFIG.get('protected_hook_phrases',[]):
            opening_text = opening_text.replace(phrase, phrase.replace(' ', '\u00a0'))
        for chunk in opening_text.split(' '):
            word = chunk.replace('\u00a0', ' ')
            next_line=f'{line} {word}' if line else word
            if line and self.tfont.getlength(next_line)>HOOK_TEXT_WIDTH:
                self.headlines.append(line)
                line=word
            else:
                line=next_line
        self.headlines.append(line)
        self.caption_font=font(31)
        self.small_font=font(15)
        self.shots=[]
        for anchor,name,box,motion,beat,dissolve in SCENES:
            original=Image.open(A/name).convert('RGB')
            crop=original.crop(box) if box else original
            bg=cover(original,816,1408).filter(ImageFilter.GaussianBlur(26))
            pix=np.asarray(bg,dtype=np.float32)
            grad=np.interp(np.arange(1408),[0,450,880,1407],[.45,.46,.30,.18])[:,None,None]
            pix=pix*grad*np.array([.84,.96,.95])+np.array([4,12,11])
            start=self.hook_end_frame if anchor is None else round((self.words[anchor]['s']-CAPTION_LEAD_SECONDS)*FPS)
            self.shots.append(dict(start=start,asset=name,crop=box,motion=motion,beat=beat,
                word_anchor=anchor,dissolve=round(FPS*dissolve),photo=crop,bg=Image.fromarray(pix.clip(0,255).astype('uint8'))))
        self.shot_starts=[s['start'] for s in self.shots]
        self.cues=self.build_cues()
        self.cue_starts=[c['start_frame'] for c in self.cues]
        self.tiles=[self.make_caption(c) for c in self.cues]

    def build_cues(self):
        cues=[]
        for i,j in CAPTION_IDS:
            ws=self.words[i:j]
            text=' '.join(w['w'] for w in ws)
            start=max(self.hook_end_frame,round(FPS*(ws[0]['s']-CAPTION_LEAD_SECONDS)))
            end=min(self.frames,round(FPS*(ws[-1]['e']+(.18 if j==len(self.words) else .11))))
            if j<len(self.words): end=min(end,round(FPS*(self.words[j]['s']-CAPTION_LEAD_SECONDS)))
            assert end>start and (not cues or start>=cues[-1]['end_frame']),(text,start,end)
            cues.append(dict(start_frame=start,end_frame=end,text=text,word_ids=list(range(i,j))))
        return cues

    def make_caption(self,c):
        text=c['text'].upper()
        f=self.caption_font
        if f.getlength(text)>CAPTION_TEXT_WIDTH: f=font(29)
        if f.getlength(text)>CAPTION_TEXT_WIDTH: f=font(27)
        if f.getlength(text)>CAPTION_TEXT_WIDTH: f=font(26)
        assert f.getlength(text)<=CAPTION_TEXT_WIDTH,(text,f.getlength(text))
        x=(W-f.getlength(text))/2
        base=Image.new('RGBA',(W,76)); yellow=base.copy()
        d=ImageDraw.Draw(base)
        d.text((x+1,54),text,font=f,anchor='ls',fill='black',stroke_width=4,stroke_fill=(0,0,0,175))
        d.text((x,51),text,font=f,anchor='ls',fill='white',stroke_width=3,stroke_fill=(8,14,14))
        ImageDraw.Draw(yellow).text((x,51),text,font=f,anchor='ls',fill='#FFD400')
        prefix=''; spans=[]
        for word in text.split():
            spans.append((x+f.getlength(prefix),x+f.getlength(prefix+word)));prefix+=word+' '
        bounds=base.getbbox()
        top=CAPTION_Y-51+bounds[1]
        bottom=CAPTION_Y-51+bounds[3]
        assert bounds[0]>=90 and bounds[2]<=630 and top>=794 and bottom<=856,bounds
        return base,yellow,spans,bounds

    def hook_frame(self,n):
        scale=max((W+HOOK_PAN_PX)/self.raw.width,800/self.raw.height)
        srcw,srch=W/scale,800/scale
        span=min(self.raw.width-srcw,HOOK_PAN_PX/scale)
        assert abs(span*scale-HOOK_PAN_PX)<1e-6
        left=(self.raw.width-srcw-span)*HOOK_PAN_START_FRACTION+span*n/(self.hook_end_frame-1)
        top=0  # Preserve the complete head; limit movement to the approved pan distance.
        photo=self.raw.resize((W,800),Image.Resampling.LANCZOS,box=(left,top,left+srcw,top+srch))
        base=Image.new('RGBA',(W,H),(18,48,41,255));base.paste(photo,(0,0))
        base=Image.alpha_composite(base,self.hook)
        d=ImageDraw.Draw(base)
        for i,line in enumerate(self.headlines):
            xy=(48,835+i*51)
            d.text((xy[0]+1,xy[1]+2),line,font=self.tfont,anchor='lt',fill='#19392C')
            d.text(xy,line,font=self.tfont,anchor='lt',fill='white')
        base.alpha_composite(self.credit_shade,(0,0))
        source_credit(base,CONFIG['hook_image'])
        return base.convert('RGB')

    def shot(self,i,n):
        s=self.shots[i]
        end=self.shots[i+1]['start'] if i+1<len(self.shots) else self.frames
        p=max(0,min(1,(n-s['start'])/max(1,end-s['start']-1)))
        mode=s['motion'];im=s['photo']
        if mode.startswith('pan'):
            zoom=1.0
            dx=29.7*(1-2*p)*(1 if mode=='pan-left' else -1)
            scale=max((W+59.4)/im.width,PHOTO_HEIGHT/im.height)
        else:
            zoom_range=.10
            zoom=1+zoom_range*(p if mode=='zoom-in' else 1-p)
            dx=0
            scale=max(W/im.width,PHOTO_HEIGHT/im.height)*zoom
        sw,sh=W/zoom,H/zoom
        left=(816-sw)/2-dx;top=(1408-sh)/2
        canvas=s['bg'].resize((W,H),Image.Resampling.BILINEAR,box=(left,top,left+sw,top+sh))
        if s['asset'] in FULL_FRAME_ASSETS:
            # Preserve the published interface and its complete text; animate only the backdrop.
            fit=min(W/im.width,PHOTO_HEIGHT/im.height)
            pw,ph=round(im.width*fit),round(im.height*fit)
            panel=Image.new('RGB',(W,PHOTO_HEIGHT),im.getpixel((0,0)))
            panel.paste(im.resize((pw,ph),Image.Resampling.LANCZOS),((W-pw)//2,(PHOTO_HEIGHT-ph)//2))
            canvas.paste(panel,(0,PHOTO_TOP))
            return canvas
        srcw,srch=min(im.width,W/scale),min(im.height,PHOTO_HEIGHT/scale)
        fx,fy=PHOTO_FOCAL_POINTS.get(s['asset'],(.5,.5))
        photo_left=min(max(0,fx*im.width-srcw/2-dx/scale),im.width-srcw)
        photo_top=min(max(0,fy*im.height-srch/2),im.height-srch)
        photo=im.resize((W,PHOTO_HEIGHT),Image.Resampling.LANCZOS,
                        box=(photo_left,photo_top,photo_left+srcw,photo_top+srch))
        canvas.paste(photo,(0,PHOTO_TOP))
        return canvas

    def frame(self,n):
        if n<self.hook_end_frame: return self.hook_frame(n)
        i=bisect.bisect_right(self.shot_starts,n)-1
        canvas=self.shot(i,n)
        k=next((k for k in (i,i+1) if 0<k<len(self.shots) and self.shots[k]['dissolve']
                and abs(n-self.shots[k]['start'])<self.shots[k]['dissolve']/2),None)
        if k is not None:
            s=self.shots[k]; alpha=.5+(n-s['start'])/s['dissolve']
            canvas=Image.blend(self.shot(k-1,n),self.shot(k,n),alpha)
        source_credit(canvas,self.shots[i]['asset'])
        ci=bisect.bisect_right(self.cue_starts,n)-1
        if ci>=0 and n<self.cues[ci]['end_frame']:
            cue=self.cues[ci]
            base,yellow,spans,_=self.tiles[ci]
            edge=spans[0][0]-1;t=n/FPS
            for wid,(left,right) in zip(cue['word_ids'],spans):
                w=self.words[wid]
                if t>=w['e']: edge=right+1
                elif t>=w['s']: edge=left+(right-left)*(t-w['s'])/max(.02,w['e']-w['s']);break
                else: break
            tile=base.copy()
            if int(edge)>0:
                box=(0,0,int(edge),76)
                tile.alpha_composite(yellow.crop(box))
            canvas.paste(tile,(0,CAPTION_Y-51),tile)
        return canvas

    def sidecars(self):
        (ROOT/'captions.json').write_text(json.dumps(self.cues,ensure_ascii=False,indent=2)+'\n')
        plain=[(max(0,self.words[i]['s']-.025),self.words[j-1]['e']+.1,
                ' '.join(w['w'] for w in self.words[i:j]))
               for i,j in [(0,5),(5,10),(10,self.hook_words)]]
        plain.extend((c['start_frame']/FPS,c['end_frame']/FPS,c['text']) for c in self.cues)
        plain=[(s,min(e,plain[i+1][0]) if i+1<len(plain) else e,t)
               for i,(s,e,t) in enumerate(plain)]
        (ROOT/'phu-de.srt').write_text('\n\n'.join(f'{i}\n{stamp(s)} --> {stamp(e)}\n{t}' for i,(s,e,t) in enumerate(plain,1))+'\n')
        cuts=[dict(sequence_start_frame=s['start'],
                  sequence_end_frame=self.shots[i+1]['start'] if i+1<len(self.shots) else self.frames,
                  asset=s['asset'],crop=s['crop'],motion=s['motion'],beat=s['beat'],spoken_word_anchor=s['word_anchor'],dissolve_frames=s['dissolve'])
              for i,s in enumerate(self.shots)]
        data=dict(resolution=[W,H],fps=FPS,frames=self.frames,duration=self.duration,
                  voice=dict(asset='assets/loi-doc-vbee.mp3',source_in=0,source_out=self.audio_duration,sequence_start=0,playback_speed=1),
                  hook=dict(sequence_start_frame=0,sequence_end_frame=self.hook_end_frame,title=self.headlines,
                            overlay='assets/khung-hook.png',motion='pan-left',pan_pixels=round(HOOK_PAN_PX,2),
                            font_size=HOOK_FONT_SIZE),
                  captions=dict(font='Inter Bold',baseline_y=CAPTION_Y,white='#FFFFFF',yellow='#FFD400'),
                  source_credits=dict(font='Inter Bold',font_size=CREDIT_FONT_SIZE,hook_xy=CREDIT_XY,body_xy=CREDIT_XY,labels=SOURCE_LABELS),
                  body_photo=dict(x=0,y=PHOTO_TOP,width=W,height=PHOTO_HEIGHT),
                  shots=cuts)
        (ROOT/'timeline.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

def render(edit, out):
    ff = ffmpeg()
    audio = A/'loi-doc-vbee.mp3'
    music = A/'nhac-nen.wav'
    voice_filter = 'loudnorm=I=-16:TP=-1.5:LRA=11'
    measured = subprocess.run(
        [ff, '-nostdin', '-hide_banner', '-i', str(audio), '-af',
         voice_filter+':print_format=json', '-f', 'null', '-'],
        capture_output=True, text=True, check=True,
    )
    levels = json.JSONDecoder().raw_decode(measured.stderr[measured.stderr.rfind('{'):])[0]
    (ROOT/'audio-measure.json').write_text(json.dumps(levels, indent=2)+'\n')
    voice_filter += (
        f":measured_I={levels['input_i']}:measured_TP={levels['input_tp']}"
        f":measured_LRA={levels['input_lra']}:measured_thresh={levels['input_thresh']}"
        f":offset={levels['target_offset']}:linear=true"
    )
    sample_count = edit.frames*48000//FPS
    music_timing = (
        f'aresample=48000,atrim=end_sample={sample_count},'
        'afade=t=in:st=0:d=0.25,'
        f'afade=t=out:st={edit.duration-.65:.6f}:d=0.65'
    )
    measurement = subprocess.run(
        [ff, '-nostdin', '-hide_banner', '-i', str(music), '-af',
         music_timing+',loudnorm=print_format=json', '-f', 'null', '-'],
        capture_output=True, text=True, check=True,
    )
    music_levels = json.JSONDecoder().raw_decode(
        measurement.stderr[measurement.stderr.rfind('{'):]
    )[0]
    music_gain = -20.0-float(music_levels['input_tp'])
    audio_graph = (
        f'[1:a]{voice_filter},aresample=48000,apad=whole_len={sample_count},'
        f'atrim=end_sample={sample_count}[voice];'
        f'[2:a]{music_timing},volume={music_gain:.2f}dB[music];'
        '[voice][music]amix=inputs=2:duration=first:normalize=0[a]'
    )
    settings = dict(
        music_asset='assets/nhac-nen.wav', music_gain_db=round(music_gain, 2),
        target_music_true_peak_dbtp=-20, fade_in_seconds=.25, fade_out_seconds=.65,
        voice_target_lufs=-16, voice_playback_speed=1,
        samples=sample_count, audio_filter_graph=audio_graph,
        music_input_measured=music_levels,
    )
    (ROOT/'mix-settings.json').write_text(json.dumps(settings, indent=2)+'\n')
    cmd = [
        ff, '-nostdin', '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}',
        '-r', str(FPS), '-i', 'pipe:0', '-i', str(audio), '-i', str(music),
        '-filter_complex', audio_graph, '-map', '0:v:0', '-map', '[a]',
        '-vf', 'scale=out_color_matrix=bt709,format=yuv420p',
        '-c:v', 'libx264', '-preset', 'fast', '-crf', '17',
        '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
        '-c:a', 'aac', '-b:a', '224k', '-ac', '2', '-ar', '48000',
        '-movflags', '+faststart', str(out),
    ]
    with subprocess.Popen(cmd, stdin=subprocess.PIPE) as proc:
        try:
            for n in range(edit.frames):
                proc.stdin.write(edit.frame(n).tobytes())
                if n % 150 == 0:
                    print(n, '/', edit.frames, flush=True)
        finally:
            proc.stdin.close()
        if proc.wait():
            raise RuntimeError('FFmpeg could not encode the video.')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,default=ROOT/'AIM-video.mp4')
    ap.add_argument('--qa',type=Path,help='Write preview stills to a QA directory instead of encoding.')
    args=ap.parse_args()
    edit=Edit();edit.sidecars()
    if args.qa:
        args.qa.mkdir(parents=True,exist_ok=True)
        frames={0,edit.hook_end_frame-1,edit.hook_end_frame,edit.frames-1}
        frames.update((s['start']+e)//2 for s,e in zip(edit.shots,edit.shot_starts[1:]+[edit.frames]))
        frames.update(round((edit.words[c['word_ids'][0]]['s']+edit.words[c['word_ids'][-1]]['e'])*FPS/2) for c in edit.cues)
        for n in sorted(frames):
            edit.frame(n).save(args.qa/f'{n:03}.jpg',quality=92)
        print(edit.headlines,edit.frames,edit.duration,flush=True)
    else:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        render(edit,args.out)

if __name__=='__main__': main()
