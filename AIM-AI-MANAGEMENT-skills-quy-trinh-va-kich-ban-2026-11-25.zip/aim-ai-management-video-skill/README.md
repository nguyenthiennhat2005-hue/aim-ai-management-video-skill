# AIM / AI MANAGEMENT — bộ skill kịch bản và video

Bản đóng gói ngày **25/11/2026**, gồm quy trình viết tin AI, định dạng Vbee và dựng video theo khung AIM đã chốt.

**Bắt đầu ở [SKILL.md](SKILL.md).** Đây là tài liệu hiện hành. Thư mục `archive/` giữ hai skill người dùng đã nạp để tra nguồn; các mặc định SanSan/See The Light được ghi đè cho AIM trong tài liệu hiện hành.

## Có trong gói

- Skill AIM tổng hợp cùng hướng dẫn viết hook/body, Vbee, ảnh, pan/zoom/fade, phụ đề, nhạc, nguồn và nghiệm thu.
- Khung xanh ngọc, logo và SVG chỉnh sửa, Inter Bold kèm OFL.
- 40 kịch bản bản cập nhật 09/11, bài 41 và bản 42 đã sửa; bản nháp 43–44 lưu riêng. Bộ JSON lời đọc, HTML duyệt và 31 bản caption/lần trả lời liên quan.
- Bản lưu **66 lượt trao đổi** trong chat “kịch bản AI”: lời người dùng và câu trả lời cuối theo thời gian, không có suy luận nội bộ/công cụ/dữ liệu đăng nhập. Bản lịch sử có cả các bản cũ; dùng catalog mới nhất khi tạo video.
- Bộ dựng Python cấu hình bằng JSON, aligner CTC, verifier và ví dụ cấu hình của tập 25 đã kiểm tra.

## Sử dụng

Giải nén thư mục này. Có thể mở `SKILL.md` để nạp vào trợ lý đang dùng, hoặc chép thư mục vào nơi lưu skill của môi trường hỗ trợ. Các script không tự cài, đăng nhập hay xuất bản.

Render yêu cầu Python và các thư viện trong `scripts/requirements.txt`; căn từ cần thêm torch, transformers và faster-whisper. Mô hình, FFmpeg và phông có thể cần thiết lập theo máy. Phiên bản của môi trường đã chạy ghi tại `scripts/runtime-versions.json`.

Khởi tạo một bài từ catalog và MP3 có sẵn:

```sh
python3 scripts/init_project.py --episode 25 --voice /path/to/25.mp3 --music /path/to/music.wav --out /path/to/project --config example-25/edit-config.json
```

Sau đó căn từ, tải/chọn ảnh, kiểm tra cấu hình và dựng theo [hướng dẫn video](references/dung-video-aim.md). `scripts/fetch_example_images.py` có thể lấy lại tư liệu công khai của ví dụ 25 từ manifest; luôn xem lại ảnh và điều khoản nguồn ở thời điểm dùng.

Không có MP3 Vbee, file nhạc, phim/video mẫu hoặc ảnh stock được nhúng sẵn. Đường dẫn máy cá nhân trong bản chat được chuẩn hóa thành `<USER_HOME>`, link tải tạm được bỏ. Tệp `SHA256SUMS` giúp kiểm tính toàn vẹn của gói.

## Phạm vi tài liệu

Đây là ảnh chụp quy trình và dữ liệu đã dùng đến ngày đóng gói, không phải xác nhận tin tức còn mới vào lần sử dụng sau. Kiểm tra lại nguồn khi viết tin mới hoặc thay đổi dữ kiện. Nhạc/ảnh/tài liệu bên ngoài giữ điều khoản của nguồn; không tự gán giấy phép mở cho toàn bộ gói.
