# Nhạc nền AIM — gói riêng

Đóng gói ngày 25/11/2026.

## Nội dung

- AIM-nhac-01-Reel-1-va-2.wav: bản nhạc dùng cho Reel 1 và 2, dài khoảng 37,10 giây.
- AIM-nhac-02-Reel-3-Vuong-Hong.wav: bản nhạc từ Reel 3, dài khoảng 39,45 giây.
- Âm thanh Reel gốc/: ba bản M4A để đối chiếu nguồn.
- Nguồn nhạc và quy ước dựng AIM.md: URL nguồn và quy ước dựng.
- manifest.json và SHA256SUMS: kích thước và checksum của các tệp.

## Dùng khi dựng video

Các file được giữ nguyên từ thư viện AIM, chưa cân cố định ở −20 dB trong file. Khi trộn, cân lớp nhạc về mức đỉnh thật khoảng −20 dBTP; fade vào 0,25 giây và ra 0,65 giây, đặt dưới giọng Vbee. Mức gain cần áp dụng phụ thuộc vào đoạn nhạc và mức đo của file, không mặc định giảm 20 dB cho mọi đầu vào. Giữ giọng rõ và kiểm tra bản xuất.

## Nguồn

Facebook hiển thị KHỞI NGHIỆP · Âm thanh gốc; chưa xác định tên bài hoặc chủ sở hữu nhạc riêng.

- https://www.facebook.com/reel/1670281907901655
- https://www.facebook.com/reel/2220861011798219
- https://www.facebook.com/reel/1496065549036217

Không gán tên bài hoặc giấy phép phỏng đoán. Gói này giữ tệp âm thanh và thông tin nguồn đã lưu cho quy trình AIM.
