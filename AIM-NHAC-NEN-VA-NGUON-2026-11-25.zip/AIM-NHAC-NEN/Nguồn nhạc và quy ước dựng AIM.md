# Nhạc nền và nguồn ảnh cho Video AIM

## Nhạc nền

- `AIM-nhac-01-Reel-1-va-2.wav` · 37,10 giây. Hai Reel Tesla Cybercab và Elon Musk/Jensen Huang có cùng đoạn nhạc. [Reel 1](https://www.facebook.com/reel/1670281907901655), [Reel 2](https://www.facebook.com/reel/2220861011798219)
- `AIM-nhac-02-Reel-3-Vuong-Hong.wav` · 39,45 giây. Nhạc nền từ Reel về Vương Hồng. [Reel 3](https://www.facebook.com/reel/1496065549036217)
- Hai tệp WAV stereo 48 kHz, 24 bit được tách từ âm thanh Reel. Thư mục **Âm thanh Reel gốc** giữ ba bản M4A để đối chiếu. Facebook hiển thị **KHỞI NGHIỆP · Âm thanh gốc**, chưa có tên bài riêng trên ba Reel.

## Áp dụng cho video AIM sau

- Chọn một trong hai bản nhạc trong thư mục này theo nhịp video. Trộn nhạc dưới lời đọc Vbee, giữ lời đọc rõ và fade nhạc ngắn ở hai đầu. Căn âm lượng theo đoạn có lời và nghe kiểm tra trên bản xuất.
- Ghi nguồn ảnh bằng **một dòng ngắn ở góc trên bên trái** theo mẫu Reel, chẳng hạn **Nguồn: Pexels**. Hiện tên nguồn chính của cảnh đang chiếu và đổi khi cảnh đổi nguồn. Trên khung 720 × 1280, bắt đầu thử tại x=72, y=84 và kiểm tra độ tương phản trên ảnh thực tế.
- Giữ tên tác giả, URL ảnh và thông tin giấy phép đầy đủ trong danh sách nguồn kèm dự án.
